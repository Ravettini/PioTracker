import { redirect } from 'next/navigation';

// Página principal - redirige al login
export default function HomePage() {
  redirect('/login');
}








